from gempa import *

banten = gempa ("banten",1.2)
palu = gempa ("palu",6.1)
cianjur = gempa ("cianjur",5.6)
jayapura = gempa ("jayapura",3.3)
garut = gempa ("garut",4.0)

banten.data_gempa()
palu.data_gempa()
cianjur.data_gempa()
jayapura.data_gempa()
garut.data_gempa()



